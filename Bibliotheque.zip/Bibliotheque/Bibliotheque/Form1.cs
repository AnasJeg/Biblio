﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Bibliotheque
{
    public partial class Form1 : Form
    {
       // string param = "SERVER=127.0.0.1; DATABASE=bibliotheque; UID=root; PASSWORD=";
        private MySqlConnection con=new MySqlConnection("SERVER=127.0.0.1; DATABASE=bibliotheque; UID=root; PASSWORD=");
       
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            DataTable dt=new DataTable();
            MySqlDataAdapter req = new MySqlDataAdapter("SELECT COUNT(*) from user where email='" + textBox1.Text+"'AND password='"+textBox2.Text+"'",con);
            req.Fill(dt);
            if (textBox1.Text == "" || textBox2.Text == "" )
            {
                DialogResult dialogClose = MessageBox.Show("Veuillez renseigner tous les champs", "Champs requis", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else if (dt.Rows[0][0].ToString()=="1")
            {
              //  Menu.label1 = dt.Rows[0][0].ToString();    
                 Menu mn = new Menu();
                mn.Show(); 
                this.Hide();
          
            }

            else
            {
                DialogResult dialogClose = MessageBox.Show("!!!", "Champs requis", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Clear();
                textBox2.Clear();
            }
        }
    }
}
